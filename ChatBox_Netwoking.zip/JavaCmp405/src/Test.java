import java.awt.EventQueue;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class Test {
	private static Socket mySocket;


	public static void main(String[] args)
	{
		
		
		
		new Connect();
		

		do {
			 Connect.keepMsg();
		}while(true);
		
		 
	
		 
	}

}
