import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.DatagramPacket;
import java.util.HashMap;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
public class Connect  extends JFrame{
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	 Font font = new Font("TimesRoman",Font.PLAIN,20);
	 Font font_1 = new Font("TimesRoman",Font.PLAIN,17);
	
	private JButton button;
	private static Socket mySocket;
private static HashMap<String, ChatBox>map=new HashMap<>();

	
	public Connect() {
		mySocket= new Socket(64000);

		setTitle("Connect Frame");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 864, 581);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("IP Address");
		label.setBounds(15, 16, 106, 46);
	contentPane.add(label);
		label.setFont(font);
	
textField = new JTextField();
	textField.setBounds(109, 26, 146, 26);
	contentPane.add(textField);
		textField.setColumns(10);
		textField.setFont(font);
		
		textField_1 = new JTextField();
		textField_1.setBounds(270, 26, 146, 26);
	contentPane.add(textField_1);
		textField_1.setColumns(10);
		textField_1.setFont(font);
		
		textField_2 = new JTextField();
		textField_2.setBounds(431, 26, 146, 26);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		textField_2.setFont(font);
		
		textField_3 = new JTextField();
		textField_3 = new JTextField();
		textField_3 = new JTextField();
		textField_3 = new JTextField();
		textField_3 = new JTextField();
		textField_3 = new JTextField();
		textField_3 = new JTextField();
		textField_3 = new JTextField();
		textField_3 = new JTextField();
		textField_3 = new JTextField();
		textField_3 = new JTextField();
	textField_3 = new JTextField();
	textField_3 = new JTextField();
		textField_3.setBounds(592, 26, 146, 26);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		textField_3.setFont(font);
		
		JLabel label_1 = new JLabel("PORT Number");
		label_1.setBounds(254, 173, 106, 37);
		contentPane.add(label_1);
		label_1.setFont(font_1);
		
		textField_4 = new JTextField();
		textField_4.setBounds(375, 178, 146, 26);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		textField_4.setFont(font);
		
		setVisible(true);
		
		
		button = new JButton("Chat");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String ip1=textField.getText();
			     String ip2=textField_1.getText();
				String ip3=textField_2.getText();
			     String ip4=textField_3.getText();
			  String ipAddress=ip1+"."+ip2+"."+ip3+"."+ip4;
				
				
			   String port= textField_4.getText();
			   int port1=Integer.parseInt(port);
		   String key= ipAddress+" "+ port;
			  
			  if(!ipAddress.isEmpty() && !port.isEmpty()&& !map.containsKey(key)) {
				  ChatBox chat=new ChatBox(mySocket,ipAddress, port1);
				  
				map.put(key, chat);
				   textField.setText("");
				   textField_1.setText("");
				   textField_2.setText("");
				   
				}
				   
			   }
			
				
		});
		button.setBounds(324, 472, 115, 37);
		contentPane.add(button);
	}
	public static void keepMsg() {
		DatagramPacket inPacket=null;
		do {
			try {
			inPacket=mySocket.receive();
				if(inPacket!=null) {
					String message=new String(inPacket.getData());
				String ip=inPacket.getAddress().getHostAddress();
				int port=inPacket.getPort();
				String key=ip+""+port;
				    ChatBox chat=null;
					if(map.containsKey(key)) {
						chat=map.get(key);
						chat.getTextArea().append(message);
						chat.setVisible(true);
						}else {
							 chat=new ChatBox(mySocket,ip,port);
							map.put(key,chat);
							chat.getTextArea().append(message);
							chat.setVisible(true);
						}					}
			
		}catch(NullPointerException npe) {				
		}
		
		}while(true);
}

}


