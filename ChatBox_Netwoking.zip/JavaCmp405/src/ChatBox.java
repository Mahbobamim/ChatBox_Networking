import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class ChatBox extends JFrame {
	private JPanel contentPane;
	private JTextField textField_1;
	private static JTextArea textArea;
	

	private int port;
	 Font font = new Font("TimesRoman",Font.PLAIN,20);
	
	private static Socket mySocket;
	private InetAddress ipAddress;

	
	
	public ChatBox(Socket mySocket,String ipHost, int port) {
	
		try {
			this.ipAddress= InetAddress.getByName(ipHost);
			}catch(UnknownHostException e) {
				e.printStackTrace();
				System.exit(-1);
			}	
		
		
	this.setPort(port);
	
	setTitle("ChatBox");
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setSize(800, 480);
	setLocationRelativeTo(null);
	setBounds(100, 100, 826, 686);
	contentPane = new JPanel();
	contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	setContentPane(contentPane);
	contentPane.setLayout(null);
	
	textField_1 = new JTextField();
	textField_1.setBounds(134, 571, 434, 43);
	contentPane.add(textField_1);
	textField_1.setColumns(10);
	textField_1.setFont(font);
	
	JLabel label = new JLabel("Enter Text");
	label.setBounds(36, 561, 159, 69);
	contentPane.add(label);
	label.setFont(font);
	JButton send = new JButton("Send");



	
	
	send.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			String message = getTextField_1().getText();
			if(!message.isEmpty()) {
		
				console(message);
				getTextField_1().setText("");
				mySocket.send(message, getAddress(), getPort());
			}
		}
	});
	

	
		

	send.setBounds(639, 571, 104, 43);
	contentPane.add(send);
	
	textArea= new JTextArea();
	textArea.setBounds(0, 0, 804, 555);
	contentPane.add(textArea);
	textArea.setFont(font);
	
	
	
	setVisible(true);
	
		
		
		
		
		
	}
	
	private int getPort() {
		return port;
	}
	private void setPort(int port) {
		this.port = port;
	}
	
	
	public final InetAddress getAddress() {
		return ipAddress;
	}
	
	final JTextArea getTextArea() {
		return textArea;
	}
	
	final void setTextArea(JTextArea textArea) {
		ChatBox.textArea = textArea; 
	}
		
	public final JTextField getTextField_1() {
		return textField_1;
	}
	
	
	
	public void console(String message) {
		
		this.textArea.append(message+ "\n");
		
	}
	
	

	
}

